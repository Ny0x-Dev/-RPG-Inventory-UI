import * as React from 'react'
import { render } from 'react-dom'
import { App } from './app/App'

import './sass/index.scss'

render(<App/>, document.querySelector('#app'))