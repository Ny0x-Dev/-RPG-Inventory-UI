# RPG-Inventory-UI
Drag &amp; Drop Inventory RPG Style using React. <br>
This is a pretty old resource!

### Todo
```
Switch to Redux
Support user keybinds
```

### Preview
![](https://i.imgur.com/4Y2YYT0.jpg)
